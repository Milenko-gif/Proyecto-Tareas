To-Do app in Android
https://www.youtube.com/watch?v=GQ9ytZC-ZkU
